package VIEW;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame implements View {

	void screenSetting() {

		frame.getContentPane();
		frame.setBounds(600, 200, 1000, 700);
		frame.setVisible(true);
		frame.setLayout(new GridLayout(1, 2));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		
		////////////////////카드2구역 시작////////////////////////////////////////
		

		
		
		
		
		
		
		
		///// 고정 왼쪽구역//////////////////////////////////////////////

		leftP.setLayout(null);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setBounds(34, 36, 432, 55);

		scrollPane.setBounds(45, 122, 405, 349);
		scrollPane.setViewportView(table);
		leftP.add(scrollPane);

		btnNewButton_2.setBounds(45, 572, 120, 42);
		leftP.add(btnNewButton_2);
		lblNewLabel_2.setBounds(200, 572, 120, 43);
		lblNewLabel_2.setFont(f2);
		lblNewLabel_2.setForeground(Color.white);
		leftP.add(lblNewLabel_2);

		label_5.setBounds(330, 572, 207, 43);
		label_5.setFont(f2);
		label_5.setForeground(Color.white);
		leftP.add(label_5);

		leftP.add(lblNewLabel_1);

		/////////////////////// 고정왼쪽구역끝///////////////////////////

		leftP.setBackground(new Color(127, 23, 30));

		rightP.setBackground(Color.RED);
		rightP.setLayout(card);
		rightP.add(mainFood);
		rightP.add(c2panel_3);

		frame.add(leftP);
		frame.add(rightP);

	}

	public MainFrame() {

		screenSetting();
		new Card1_MainMenu();
		new Card2_OptionMenu();
	}

	public static void main(String[] args) {
		new MainFrame();
		

	}

}
