package VIEW;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import CONTROL.TmpCont;

public class HandlerMainFood implements View, ActionListener {
	TmpCont tmpcont =  new TmpCont();
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
			JButton actB = (JButton) e.getSource();
			
			
			//취향물어보기
			String[] hot1 = {"매운맛","중간맛","순한맛"};
			String[] hot2 = {"많이얼얼","중간얼얼","얼얼한맛 빼기"};
			int hot1_res = JOptionPane.showOptionDialog(null, "매운맛을골라주세요","매운맛선택", 1, 1, null, hot1, -1);
			int hot2_res = JOptionPane.showOptionDialog(null, "얼얼한맛을골라주세요","매운맛선택", 1, 1, null, hot2, -1);
			
			int menuNum = -1;
			switch(actB.getText()){
			
			case "마라탕(대) : 23,000원": menuNum = 0;
				break;
				
			case "마라탕(중) : 19,000원":menuNum = 1;
				break;
				
			case "마라탕(소) : 15,000원":menuNum = 2;
				break;
				
			case "마라샹궈(대) : 23,000원":menuNum = 3;
				break;
				
			case "마라샹궈(중) : 19,000원":menuNum = 4;
				break;
				
			case "마라샹궈(소) : 15,000원":menuNum = 5;
				break;
			}
				tmpcont.input(menunameHM[menuNum],priceHM[menuNum],hot1[hot1_res]+"/"+hot2[hot2_res]);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		}


	public void showList(Vector<Vector> allList) {

		
		while(model.getRowCount() > 0){
			
			model.removeRow(0);
			
		}
		
		for(Vector v : allList){
			
			model.addRow(v);
			
		}
		
		
		
		
		
		
	}


	public void showPrice(int nowPrice) {
		
		String s = nowPrice+"";
		label_5.setText(s);
		
		
		
		
	}

	

}
