package VIEW;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Font;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public interface View {

//	HashMap<String, String> menunameHM = new HashMap<>();
//	HashMap<String, Integer> priceHM = new HashMap<>();

	
	String[] menunameHM = {"마라탕(대)","마라탕(중)", "마라탕(소)", "마라샹궈(대)","마라샹궈(중)","마라샹궈(소)"};
	int[] priceHM = {23000,19000,15000,23000,19000,15000};
	MoveCard cardmove = new MoveCard();
	///////////
	HandlerMainFood hd = new HandlerMainFood();
	CardLayout card = new CardLayout();
	Font f2 = new Font("돋움",Font.BOLD, 20);
	Font f = new Font("돋움",Font.BOLD, 015);
	Font f3 = new Font("돋움",Font.BOLD, 30);
	///// 메인메뉴 존 card1/////////////////////////////////////

	JPanel mainFood = new JPanel();
	// 버튼버튼
	JButton btnNewButton = new JButton("마라탕(대) : 23,000원");
	JButton button = new JButton("마라샹궈(대) : 23,000원");
	JButton button_1 = new JButton("마라탕(중) : 19,000원");
	JButton button_2 = new JButton("마라샹궈(중) : 19,000원");
	JButton button_3 = new JButton("마라탕(소) : 15,000원");
	JButton button_4 = new JButton("마라샹궈(소) : 15,000원");

	// 라벨라벨

	ImageIcon mara = new ImageIcon("E:\\MR\\te5.jpg");
	ImageIcon maraS = new ImageIcon("E:\\MR\\s.jpg");
	JLabel label = new JLabel(maraS);
	JLabel lblNewLabel = new JLabel(mara);
	JLabel label_1 = new JLabel(mara);
	JLabel label_2 = new JLabel(maraS);
	JLabel label_3 = new JLabel(mara);
	JLabel label_4 = new JLabel(maraS);
	
	JLabel minitTitle = new JLabel("메인 메뉴를 골라주세요");

	// 하단버튼

	JPanel panel_2 = new JPanel();
	JButton button_5 = new JButton("이전단계");
	JButton button_6 = new JButton("다음단계");
	////////////////////////card1끝!!!//////////////////////////
	
	
	
	/////////////////////////////card2/////////////////////////
	
	

	
	JPanel c2panel_3 = new JPanel();
	
	
	
	
	
	
	
	
	
	
	
	/////////////////// 왼쪽패널 고정존////////////////////////

	JLabel lblNewLabel_1 = new JLabel("타이틀구역");
	JScrollPane scrollPane = new JScrollPane();
	String[] lsit= {"메뉴","수량","가격","기타"};
	String[][] s = null;
	DefaultTableModel model = new DefaultTableModel(null, lsit);
	JTable table = new JTable(model);
	JButton btnNewButton_2 = new JButton("선택삭제");
	JLabel lblNewLabel_2 = new JLabel("합계 :   \\");
	JLabel label_5 = new JLabel("0");

	
	
	
	
	
	
	
	
	
	
	//////////////////기본프레임////////////////////
	JFrame frame = new JFrame();
	JPanel leftP = new JPanel();
	JPanel rightP = new JPanel();
	JButton a = new JButton("a");
	JButton b = new JButton("b");

}
