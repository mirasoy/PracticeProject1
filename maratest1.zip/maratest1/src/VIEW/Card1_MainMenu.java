package VIEW;

import java.awt.Color;

import javax.swing.SwingConstants;

public class Card1_MainMenu implements View{
	public Card1_MainMenu() {
		mainFood.setLayout(null);
		minitTitle.setBounds(15, 15, 472, 53);
		minitTitle.setBackground(Color.black);
		minitTitle.setFont(f3);
		minitTitle.setHorizontalAlignment(SwingConstants.CENTER);
		mainFood.add(minitTitle);

		btnNewButton.setBounds(60, 175, 172, 23);
		mainFood.add(btnNewButton);

		button.setBounds(250, 175, 172, 23);
		mainFood.add(button);

		button_1.setBounds(60, 326, 172, 23);
		mainFood.add(button_1);

		button_2.setBounds(250, 326, 172, 23);
		mainFood.add(button_2);

		button_3.setBounds(60, 479, 172, 23);
		mainFood.add(button_3);

		button_4.setBounds(250, 479, 172, 23);
		mainFood.add(button_4);

		lblNewLabel.setBounds(60, 70, 158, 95);
		label.setBounds(250, 70, 158, 95);
		label_1.setBounds(60, 221, 158, 95);
		label_2.setBounds(250, 221, 158, 95);
		label_3.setBounds(60, 374, 158, 95);
		label_4.setBounds(250, 374, 158, 95);
		//

		//
		mainFood.add(lblNewLabel);
		mainFood.add(label);
		mainFood.add(label_1);
		mainFood.add(label_2);
		mainFood.add(label_3);
		mainFood.add(label_4);
		//

		// 하단버튼
		panel_2.setLayout(null);
		panel_2.setBounds(0, 551, 492, 111);
		button_5.setBounds(110, 21, 120, 42);
		button_5.setEnabled(false);
		button_5.setBackground(Color.DARK_GRAY);
		button_6.setBounds(260, 21, 120, 42);
		panel_2.add(button_5);
		panel_2.add(button_6);
		mainFood.add(panel_2);

		
		
		button_6.addActionListener(cardmove);
//		button_5.addActionListener(cardmove);
		btnNewButton.addActionListener(hd);
		button.addActionListener(hd);
		button_1.addActionListener(hd);
		button_2.addActionListener(hd);
		button_3.addActionListener(hd);
		button_4.addActionListener(hd);
		//////////////////카드1구역 끝///////////////////////////////////////
			}
}
