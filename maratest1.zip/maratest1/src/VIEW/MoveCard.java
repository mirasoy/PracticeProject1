package VIEW;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class MoveCard implements View,ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		JButton actB = (JButton) e.getSource();	
		
		switch(actB.getText()){
		case "이전단계" :
			card.previous(rightP);
			break;
			
		case "다음단계" :card.next(rightP);
			break;
		
		
		}
		
		
		
		
		
		
		
	}

}
