package VIEW;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import java.awt.Font;

public class Ad {

	private JFrame frame;
	private final 

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ad window = new Ad();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Ad() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1000, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(0,2));
		
		
		
		
		JPanel c2panel_3 = new JPanel();
		
		
		JPanel c2panel_2 = new JPanel();
		c2panel_2.setBounds(0, 551, 492, 111);
		c2panel_2.setLayout(null);
		
		JButton c2btnNewButton = new JButton("이전단계");
		c2btnNewButton.setBounds(110, 21, 120, 42);
		c2panel_2.add(c2btnNewButton);
		
		JButton c2button = new JButton("다음단계");
		c2button.setBounds(260, 21, 120, 42);
		c2panel_2.add(c2button);
		c2panel_3.setBackground(Color.WHITE);
		c2panel_3.setBounds(0, 0, 492, 552);
		c2panel_3.setLayout(new GridLayout(8, 1, 0, 0));
		
		
		
	
		
		JPanel c2panel_1 = new JPanel();
		c2panel_3.add(c2panel_1);
		c2panel_1.setLayout(null);
		
		JLabel c2_label_2 = new JLabel("기본 재료가 포함되어 있는 상태입니다, 추가하실 옵션을 고르세요. (각 1000원)");
		c2_label_2.setFont(new Font("굴림", Font.BOLD, 12));
		c2_label_2.setBounds(12, 6, 480, 15);
		c2panel_1.add(c2_label_2);
		
		JLabel lblRlqhswo = new JLabel("<html>기본구성 : 청경채, 숙주, 배추, 새송이, 느타리, 목이버섯, 건두부, 푸주, 옥수수면, 중국당면, 고기 1종</html>");
		lblRlqhswo.setFont(new Font("굴림", Font.PLAIN, 11));
		lblRlqhswo.setBounds(33, 31, 436, 34);
		c2panel_1.add(lblRlqhswo);
		
		JPanel c2panel_4 = new JPanel();
		c2panel_3.add(c2panel_4);
		c2panel_4.setLayout(null);
		
		JLabel c2label_1 = new JLabel("[면류]");
		c2label_1.setBounds(22, 10, 57, 15);
		c2panel_4.add(c2label_1);
		
		JButton c2button_4 = new JButton("납작당면");
		c2button_4.setBounds(20, 36, 97, 23);
		c2panel_4.add(c2button_4);
		
		JButton c2button_5 = new JButton("옥수수면");
		c2button_5.setBounds(137, 36, 97, 23);
		c2panel_4.add(c2button_5);
		
		JButton c2button_6 = new JButton("분모짜");
		c2button_6.setBounds(254, 36, 97, 23);
		c2panel_4.add(c2button_6);
		
		JButton c2button_7 = new JButton("수정당면");
		c2button_7.setBounds(371, 36, 97, 23);
		c2panel_4.add(c2button_7);
		
		JPanel c2panel_5 = new JPanel();
		c2panel_3.add(c2panel_5);
		c2panel_5.setLayout(null);
		
		JLabel c2label = new JLabel("[채소]");
		c2label.setBounds(22, 10, 57, 15);
		c2panel_5.add(c2label);
		
		JButton c2btnNewButton_1 = new JButton("배추");
		c2btnNewButton_1.setBounds(20, 36, 97, 23);
		c2panel_5.add(c2btnNewButton_1);
		
		JButton c2button_1 = new JButton("감자");
		c2button_1.setBounds(137, 36, 97, 23);
		c2panel_5.add(c2button_1);
		
		JButton c2button_2 = new JButton("청경채");
		c2button_2.setBounds(254, 36, 97, 23);
		c2panel_5.add(c2button_2);
		
		JButton c2button_3 = new JButton("숙주");
		c2button_3.setBounds(371, 36, 97, 23);
		c2panel_5.add(c2button_3);
		
		JPanel c2panel_6 = new JPanel();
		c2panel_6.setLayout(null);
		c2panel_3.add(c2panel_6);
		
		JLabel c2label_2 = new JLabel("[버섯류]");
		c2label_2.setBounds(22, 10, 57, 15);
		c2panel_6.add(c2label_2);
		
		JButton c2button_8 = new JButton("팽이버섯");
		c2button_8.setBounds(20, 36, 97, 23);
		c2panel_6.add(c2button_8);
		
		JButton c2button_9 = new JButton("느타리버섯");
		c2button_9.setBounds(137, 36, 97, 23);
		c2panel_6.add(c2button_9);
		
		JButton c2button_10 = new JButton("새송이버섯");
		c2button_10.setBounds(254, 36, 97, 23);
		c2panel_6.add(c2button_10);
		
		JButton c2button_11 = new JButton("목이버섯");
		c2button_11.setBounds(371, 36, 97, 23);
		c2panel_6.add(c2button_11);
		
		JPanel c2panel_7 = new JPanel();
		c2panel_7.setLayout(null);
		c2panel_3.add(c2panel_7);
		
		JLabel c2label_3 = new JLabel("[해산물]");
		c2label_3.setBounds(22, 10, 57, 15);
		c2panel_7.add(c2label_3);
		
		JButton c2button_12 = new JButton("새우");
		c2button_12.setBounds(20, 36, 97, 23);
		c2panel_7.add(c2button_12);
		
		JButton c2button_13 = new JButton("어묵");
		c2button_13.setBounds(137, 36, 97, 23);
		c2panel_7.add(c2button_13);
		
		JButton c2button_14 = new JButton("관자");
		c2button_14.setBounds(254, 36, 97, 23);
		c2panel_7.add(c2button_14);
		
		JButton c2button_15 = new JButton("오징어");
		c2button_15.setBounds(371, 36, 97, 23);
		c2panel_7.add(c2button_15);
		
		JPanel c2panel_8 = new JPanel();
		c2panel_8.setLayout(null);
		c2panel_3.add(c2panel_8);
		
		JLabel c2label_4 = new JLabel("[기타]");
		c2label_4.setBounds(22, 10, 57, 15);
		c2panel_8.add(c2label_4);
		
		JButton c2button_16 = new JButton("삶은달걀");
		c2button_16.setBounds(20, 36, 97, 23);
		c2panel_8.add(c2button_16);
		
		JButton c2button_17 = new JButton("게맛살");
		c2button_17.setBounds(137, 36, 97, 23);
		c2panel_8.add(c2button_17);
		
		JButton c2button_18 = new JButton("스팸");
		c2button_18.setBounds(254, 36, 97, 23);
		c2panel_8.add(c2button_18);
		
		JButton c2button_19 = new JButton("비앤나");
		c2button_19.setBounds(371, 36, 97, 23);
		c2panel_8.add(c2button_19);
		
		JPanel c2panel_9 = new JPanel();
		c2panel_9.setLayout(null);
		c2panel_3.add(c2panel_9);
		
		JLabel c2label_5 = new JLabel("[옵션고기선택]");
		c2label_5.setBounds(22, 10, 114, 15);
		c2panel_9.add(c2label_5);
		
		JRadioButton c2rdbtnNewRadioButton = new JRadioButton("소고기");
		c2rdbtnNewRadioButton.setBounds(36, 31, 73, 23);
		c2panel_9.add(c2rdbtnNewRadioButton);
		
		JRadioButton c2radioButton = new JRadioButton("양고기");
		c2radioButton.setBounds(145, 31, 66, 23);
		c2panel_9.add(c2radioButton);
		
		JRadioButton c2radioButton_2 = new JRadioButton("고기없음(다른재료랜덤추가)");
		c2radioButton_2.setBounds(247, 31, 207, 23);
		c2panel_9.add(c2radioButton_2);
		
		JPanel c2panel_11 = new JPanel();
		c2panel_11.setLayout(null);
		c2panel_3.add(c2panel_11);
		
		JLabel c2label_6 = new JLabel("[고기 추가] : 100g 3,000원");
		c2label_6.setBounds(22, 10, 182, 15);
		c2panel_11.add(c2label_6);
		
		JButton c2button_20 = new JButton("소고기");
		c2button_20.setBounds(20, 36, 97, 23);
		c2panel_11.add(c2button_20);
		
		JButton c2button_21 = new JButton("양고기");
		c2button_21.setBounds(137, 36, 97, 23);
		c2panel_11.add(c2button_21);
		
		JButton button_2 = new JButton("");
		button_2.setBounds(269, 23, 97, 23);
		c2panel_11.add(button_2);
		
		JButton button_3 = new JButton("");
		button_3.setBounds(383, 23, 97, 23);
		c2panel_11.add(button_3);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 492, 69);
		panel.setLayout(null);
		
		JLabel label = new JLabel("[고기 추가] : 3,000원");
		label.setBounds(22, 10, 182, 15);
		panel.add(label);
		
		JButton button = new JButton("소고기");
		button.setBounds(20, 36, 97, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("양고기");
		button_1.setBounds(137, 36, 97, 23);
		panel.add(button_1);
	}
}
