package CONTROL;

import MODEL.TmpList;
import VIEW.HandlerMainFood;
import VIEW.View;

public class TmpCont implements View {
	TmpList tmplist =  new TmpList();

	
	
	public void input(String string, int i, String string2) {
		tmplist.connect(string, i, string2);
		hd.showList(tmplist.allList());
		hd.showPrice(tmplist.nowPrice());
		
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
