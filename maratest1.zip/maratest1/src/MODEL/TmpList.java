package MODEL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class TmpList {
	PreparedStatement pstmt;
	Connection con;
	ResultSet rs;
	Statement statement;
	

	public void connect(String menu, int price, String option) {
		connect();
		String inputSTR = "insert into tmp(menu,count,price,option) values (?,?,?,?)";
		String updateSTR = "update  tmp set count =?, price = ? where no=?";

		try {
			statement = con.createStatement();
			rs = statement.executeQuery("SELECT * FROM TMP ");

			while (rs.next()) {

				if (rs.getString(2).equals(menu) && rs.getString(5).equals(option)) {
					pstmt = con.prepareStatement(updateSTR);
					int countUP = rs.getInt(3) + 1;
					pstmt.setInt(1, countUP);
					pstmt.setInt(2, countUP * price);
					pstmt.setInt(3, rs.getInt(1));
					pstmt.executeUpdate();
					return;
				}
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {

			pstmt = con.prepareStatement(inputSTR);
			pstmt.setString(1, menu);
			pstmt.setInt(2, 1);
			pstmt.setInt(3, price);
			pstmt.setString(4, option);
			pstmt.executeUpdate();
			System.out.println(10);

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public Vector<Vector> allList() {
		Vector tmplist =new Vector<>(); 
		connect();
		try {
			statement = con.createStatement();
			rs = statement.executeQuery("SELECT * FROM TMP ");
			
			while (rs.next()) {
				Vector v = new Vector<>();
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				v.add(rs.getString(5));
				
				tmplist.add(v);
			}
			
			
		}  catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
				if (con != null) {
					con.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return tmplist;
	}
	
	
	public int nowPrice(){
		connect ();
		String priceSum = "select sum(price) from tmp";
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
			statement = con.createStatement();
			rs = statement.executeQuery(priceSum);
			rs.next();
			System.out.println(rs.getInt(1));
			return rs.getInt(1);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
		
		
		
		
		
		
	
	public void connect () {
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
