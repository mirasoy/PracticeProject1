package model;

import static res.R.*;

public class Dao {

	private final int MAX = 100;
	private int idx;
	private int top=0;
	private Gmodel[] gArr = new Gmodel[MAX];
	private Gmodel[] rankArr = new Gmodel[MAX];

	private Dao() {
	}

	private static Dao daoins;

	public static Dao getIns() {
		if (daoins == null) {

			daoins = new Dao();
		}
		return daoins;
	}

	public void makeR() {
		
//		
		for (int i = 0; i < top; i++) {
			rankArr[i] = gArr[i];
		}

		for (int i = 0; i < top; i++) {
			for (int j = 0; i + j < top; j++) {
				if (rankArr[i].getAv() > rankArr[i + j].getAv()) {
					rankArr[i] = rankArr[i];
				} else {
					Gmodel tmp = rankArr[i];
					rankArr[i] = rankArr[i + j];
					rankArr[i + j] = tmp;
				}

			}
		}

		for (int i = 0; i < top; i++) {
			for (int j = 0; j < top; j++) {
				if (gArr[i].getIdx() == rankArr[j].getIdx()) {
					gArr[i].setRank(j+1);
				}
			}
		}

	}

	public void inputD() {

		((Gmodel) dt.get("one")).setIdx(idx++);
		gArr[top++] = (Gmodel) dt.get("one");
		makeR();
		gArr[top-1] = (Gmodel) dt.get("one");
		m(gArr[top-1].toString());
		m("�Է¿Ϸ�");

	}

	public void outputD() {

				
		
	}
	

}
