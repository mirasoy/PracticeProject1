package view;

public class Alignment implements View {

	@Override
	public void display() {

	}

}
