package control;

import static res.R.*;

public class Crt {

	public void service() {

		dt.put("no", 0);

		menu.display();

		switch ((int) dt.get("no")) {
		case 1:
			ip.display();
			dao.inputD();
			break;
		case 2 :
			op.display();
			dao.outputD();
			break;
		
		}

		service();

	}

}
