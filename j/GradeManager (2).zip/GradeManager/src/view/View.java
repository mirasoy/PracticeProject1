package view;

import res.R;

public interface View extends R{

	void display();
	
	
}
