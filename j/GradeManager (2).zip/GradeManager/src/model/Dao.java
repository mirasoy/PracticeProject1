package model;

import static res.R.*;

public class Dao {

	private final int MAX = 100;
	private int idx;
	private int top = 0;
	private Gmodel[] gArr = new Gmodel[MAX];
	private Gmodel[] rankArr = new Gmodel[MAX];

	private Dao() {
	}

	private static Dao daoins;

	public static Dao getIns() {
		if (daoins == null) {

			daoins = new Dao();
		}
		return daoins;
	}

	public boolean empty() {

		if (top == 0) {
			m("�Էµ� ������ �����ϴ�.");
			return false;
		}
		return true;
	}

	public void makeR() {

		//
		for (int i = 0; i < top; i++) {
			rankArr[i] = gArr[i];
		}

		for (int i = 0; i < top; i++) {
			for (int j = 0; i + j < top; j++) {
				if (rankArr[i].getAv() > rankArr[i + j].getAv()) {
					rankArr[i] = rankArr[i];
				} else {
					Gmodel tmp = rankArr[i];
					rankArr[i] = rankArr[i + j];
					rankArr[i + j] = tmp;
				}

			}
		}

		for (int i = 0; i < top; i++) {
			for (int j = 0; j < top; j++) {
				if (gArr[i].getIdx() == rankArr[j].getIdx()) {
					gArr[i].setRank(j + 1);
				}
			}
		}

	}

	public void inputD() {

		((Gmodel) dt.get("one")).setIdx(idx++);
		gArr[top++] = (Gmodel) dt.get("one");
		makeR();
		gArr[top - 1] = (Gmodel) dt.get("one");
		m(gArr[top - 1].toString());
		m("�Է¿Ϸ�");

	}

	public void outputD() {

		Gmodel[] garr = new Gmodel[top];

		for (int i = 0; i < top; i++) {
			Gmodel g = new Gmodel();
			g.setName(gArr[i].getName());
			g.setTotal(gArr[i].getTotal());
			g.setAv(gArr[i].getAv());
			g.setEn(gArr[i].getEn());
			g.setIdx(gArr[i].getIdx());
			g.setKr(gArr[i].getKr());
			g.setMath(gArr[i].getMath());
			g.setRank(gArr[i].getRank());
			garr[i] = g;

		}
		dt.put("arr", garr);

	}

	public void outputR() {

		Gmodel[] garr = new Gmodel[top];

		for (int i = 0; i < top; i++) {
			Gmodel g = new Gmodel();
			g.setName(rankArr[i].getName());
			g.setTotal(rankArr[i].getTotal());
			g.setAv(rankArr[i].getAv());
			g.setEn(rankArr[i].getEn());
			g.setIdx(rankArr[i].getIdx());
			g.setKr(rankArr[i].getKr());
			g.setMath(rankArr[i].getMath());
			g.setRank(rankArr[i].getRank());
			garr[i] = g;

		}
		dt.put("arr", garr);

	}

	public void search() {
		int cnt = 0;
		Gmodel[] ga = new Gmodel[MAX];
		for (int i = 0; i < top; i++) {

			if (gArr[i].getName().equalsIgnoreCase((String) dt.get("name"))) {
				Gmodel g = new Gmodel();
				g.setName(gArr[i].getName());
				g.setTotal(gArr[i].getTotal());
				g.setAv(gArr[i].getAv());
				g.setEn(gArr[i].getEn());
				g.setIdx(gArr[i].getIdx());
				g.setKr(gArr[i].getKr());
				g.setMath(gArr[i].getMath());
				g.setRank(gArr[i].getRank());
				ga[cnt++] = g;
			}

		}

		Gmodel[] ga2 = new Gmodel[cnt];
		for (int i = 0; i < cnt; i++) {
			ga2[i] = ga[i];
		}

		dt.put("arr", ga2);

	}

	public void modifyD() {

		for (int i = 0; i < top; i++) {

			if (gArr[i].getIdx() == ((int) dt.get("idx"))) {

				switch ((int) dt.get("mdfno")) {
				case 1:
					m("������ �̸��� �Է��ϼ���");
					gArr[i].setName(sc.next());
					break;

				case 2:
					m("������ ������ �Է��ϼ���");
					gArr[i].setKr(sc.nextInt());
					break;
				case 3:
					m("������ ������ �Է��ϼ���");
					gArr[i].setEn(sc.nextInt());
					break;
				case 4:
					m("������ ������ �Է��ϼ���");
					gArr[i].setMath(sc.nextInt());
					break;
				default:
					m("�߸����Է��Դϴ�");

				}

				gArr[i].setTotal(gArr[i].getEn() + gArr[i].getKr() + gArr[i].getMath());
				gArr[i].setAv((gArr[i].getEn() + gArr[i].getKr() + gArr[i].getMath()) / 3);

			}

		}

		makeR();

	}

	public void deleteD() {
		for (int i = 0; i < top; i++) {

			if (gArr[i].getIdx() == ((int) dt.get("idx"))) {

				for (int j = 0; j < top; j++) {
					gArr[j] = gArr[j + 1];
				}

				m("������ �Ϸ�Ǿ����ϴ�");
				top--;
				makeR();

			}
		}

	}

}
