package main;

import static res.R.*;

import control.Crt;

public class MainRun {
	
	                                                                                                                                                                                                                                                                                                                                                                                                            
public static void main(String[] args){
	
	
	m("�����������α׷��� �����մϴ�.");
	new Crt().service();
	
	
	
	
	
}
}
